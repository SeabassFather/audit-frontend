# AuditDNA SSR Project
This project uses Next.js for SSR frontend and Express for backend.
