// Next.js config for SSR API proxy
