import React from "react";
export default function Settings() {
  return (
    <div className="text-green-400 text-2xl font-bold">
      Settings Panel Coming Soon!
    </div>
  );
}