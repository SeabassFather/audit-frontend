import React, { useEffect, useState } from "react";
// ... (full code as in previous patch, omitted for brevity)
export default function LegalsHub() {
  // ... same as above
}
