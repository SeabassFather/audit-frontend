import React from "react";
import FileUpload from "../features/files/FileUpload";
export default function FilesPage(){ return <FileUpload/>; }