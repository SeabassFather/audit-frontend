import React from "react";
import CommodityExplorer from "../features/ag/CommodityExplorer";

export default function MarketPrices(){
  return (
    <div className="container-w py-6">
      <CommodityExplorer />
    </div>
  );
}