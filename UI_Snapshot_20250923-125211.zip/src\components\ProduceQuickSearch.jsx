import React, { useState } from "react";
import { submitProduceLead } from "../api/leads";
// ... (full code as in previous patch, omitted for brevity)
export default function ProduceQuickSearch() {
  // ...
}
