import React from "react";
export default function ElderAbuseScan() {
  return (
    <div className="max-w-3xl mx-auto py-10 px-4">
      <h1 className="text-2xl font-bold mb-4">Elder Financial Abuse Scan</h1>
      <p>Scan financial records for elder abuse, missing funds, and fraud triggers. Auto-generate compliance reports.</p>
      {/* TODO: Upload, results, consent widgets */}
    </div>
  );
}
