import React from "react";
import AgOnboardingForm from "../features/ag/AgOnboardingForm";
export default function AgMarketplaceSearchPage(){ return <AgOnboardingForm/>; }