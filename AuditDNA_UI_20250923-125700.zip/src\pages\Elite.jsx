import React from "react";
export default function Elite() {
  return (
    <div className="p-4">
      <h2 className="h2">AuditDNA Elite</h2>
    </div>
  );
}
