import React from "react";
import CommodityExplorer from "../features/ag/CommodityExplorer";
export default function AgPage() {
  return <CommodityExplorer />;
}
