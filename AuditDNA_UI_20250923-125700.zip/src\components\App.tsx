import React from "react";
import AuditDNAClean from "./auditdna_futuristic_platform";

function App() {
  return <AuditDNAClean />;
}

export default App;
