import React from "react";
export default function LenderMatch() {
  return (
    <div className="p-4">
      <h2 className="h2">Lender Match</h2>
      <div className="empty">connect backend</div>
    </div>
  );
}
