import React from "react";
export default function NotFound() {
  return <div className="p-4">Not Found.</div>;
}
