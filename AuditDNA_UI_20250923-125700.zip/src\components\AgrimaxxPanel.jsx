import React, { useState } from "react";
// ... (full code as in previous patch, omitted for brevity)
export default function AgrimaxxPanel() {
  // ...
}
