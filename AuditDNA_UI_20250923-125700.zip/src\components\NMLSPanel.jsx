import React from "react";
export default function NMLSPanel() {
  return (
    <div className="border rounded-xl p-3 mb-2 bg-green-50">
      <b>NMLS #137694:</b> AuditDNA is a registered company. For compliance
      questions, see our legal page.
    </div>
  );
}
