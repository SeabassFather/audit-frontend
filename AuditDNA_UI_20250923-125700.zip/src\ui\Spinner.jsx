import React from "react";
export default function Spinner() {
  return <div className="small-muted">Loading</div>;
}
