import React from "react";
export default function EnginesPanel(){
  return(<div className='engines'>
    <span className='pill ok'>USDA</span>
    <span className='pill ok'>Compliance</span>
    <span className='pill warn'>Zadarma</span>
    <span className='pill ok'>LenderMatch</span>
  </div>);
}