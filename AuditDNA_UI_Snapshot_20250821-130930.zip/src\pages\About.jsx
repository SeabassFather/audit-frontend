import React from "react";
export default function About(){ return(<div className='card'><h2>About AuditDNA</h2><ul>
  <li>USDA ingestion, compliance workflows, lender matching, analytics.</li>
  <li>Modular service tree with clear SLAs and audit trails.</li>
  <li>CSV import/export, PDF generation, dashboard KPIs.</li>
</ul></div>); }