export const COMMODITIES = [
  "Papaya",
  "Orange",
  "Apple",
  "Grape",
  "Tomato",
  "Avocado",
  "Lemon",
  "Lime",
  "Mango",
  "Banana"
];